import yaml
from GDRoute import batch_download
import os
import json
import pandas as pd
from tqdm import tqdm
import time
from pathlib import Path
from datetime import datetime

def check_od_file(params):
    """
    """
    gd_folder = Path(params['gd_folder'])
    exist_rowidx_file = Path(params['exist_rowid_file'])

    # 判断高德数据文件夹是否存在，如果不存在，则创建
    if not os.path.exists(gd_folder):
        os.makedirs(gd_folder)
    
    # exist_rowidx_file: 记录所有 rowidx
    # 
    set_exist_idx = set()
    if os.path.exists(exist_rowidx_file):
        with open(exist_rowidx_file, 'r') as fo:
            for line in fo:
                set_exist_idx.add(line.strip())

    # 遍历高德文件夹所有高德数据
    list_files = list(gd_folder.glob("*.json"))
    for infile in list_files:
        list_lines = []
        with open(infile, 'r') as fo:
            for _, line in enumerate(fo):
                # 记录已下载数据
                json_doc = json.loads(line)
                if json_doc['success'] != 1:
                    continue
                
                list_lines.append(json.dumps(json_doc))
                if json_doc['rowidx'] not in set_exist_idx:
                    set_exist_idx.add(json_doc['rowidx'])
        # 保存下载后的数据
        with open(infile, 'w') as fp:
            for line in list_lines:
                fp.write(line + "\n")
    
    list_rowidx = list(set_exist_idx)
    with open(exist_rowidx_file, 'w') as fp:
        # 保存已有rowidx
        for rowidx in list_rowidx:
            fp.write(rowidx + "\n")
    return len(list_rowidx)

def check_data_completion(params):
    """
    """  
    set_exist_idx = set()
    exist_rowidx_file = params['exist_rowid_file']
    with open(exist_rowidx_file, 'r') as fo:
        for line in fo:
            set_exist_idx.add(line.strip())    

    # 读取OD文件，获取所有rowidx
    od_info_file = params['od_file']
    df_od_info = pd.read_csv(od_info_file)
    if os.path.exists(exist_rowidx_file):
        with open(exist_rowidx_file, 'r') as fo:
            for line in fo:
                set_exist_idx.add(line.strip())  

    return df_od_info[~df_od_info['rowidx'].isin(set_exist_idx)].copy()

def download_gd_data(df_od_info, gd_drivinginfo_file, params, mode = "transit", node_num = 4):
    """
    """
    mode = params['mode']
    exist_rowid_file = params['exist_rowid_file']

    step = 10
    for sidx in tqdm(range(0, df_od_info.shape[0], step)):
        df_tmp = df_od_info.iloc[sidx : sidx + step].copy()

        curtime = datetime.now()
        isworkday = 1 if curtime.weekday() <= 5 else 0
        hour = curtime.hour
        df_tmp = df_tmp[(df_tmp['isWorkday'] == isworkday) &
                        (hour >= df_tmp['sHour']) &
                        (hour < df_tmp['eHour'])].copy()
        
        if df_tmp.shape[0] == 0:
            continue

        s = time.time()
        list_lines = batch_download(df_tmp, mode, node_num=node_num)
        print("len(list_lines): ", len(list_lines))
        list_new_ids = []
        with open(gd_drivinginfo_file, 'a') as fp:
            for line in list_lines:
                json_doc = json.loads(line)
                if json_doc['success'] == 1:
                    list_new_ids.append(json_doc['rowidx'])
                fp.write(line + "\n")
        
        with open(exist_rowid_file, 'a') as fp:
            for rowidx in list_new_ids:
                fp.write(rowidx + "\n")

        e = time.time()
        print(sidx, "use time", int(e-s), "s")

if __name__ == "__main__":
    configfile = "config.yaml"
    time.sleep(30200)
    params = yaml.safe_load(open(configfile, 'r'))

    od_info_file = params['od_file']
    
    itercount = 0
    while True:
        print("Check the correction of the download file, delete the wrong line")
        lenvalidrecords = check_od_file(params)
        print("The number of retrieved rows is ", lenvalidrecords)

        df_od_info = check_data_completion(params)
        print("the number of rows for unretrieved data", df_od_info.shape[0])
        if df_od_info.shape[0] == 0:
            break
        
        gd_download_folder = Path(params['gd_folder'])
        gd_drivinginfo_file = gd_download_folder/(f"{datetime.now().strftime('%Y%m%d')}.json")
        download_gd_data(df_od_info, gd_drivinginfo_file, params, mode= params['mode'], node_num=3)

        # itercount += 1
        # if itercount > 5:
        #     print("The work has been itereted five rounds. Check is there any error!!")
        #     break
        # break
