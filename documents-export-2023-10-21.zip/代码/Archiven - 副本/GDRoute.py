import pandas as pd
import GDKeyPool 
import urllib
import requests
import certifi
from itertools import repeat
import requests
import certifi  

def GDRoute(mode="transit", slng = 0, slat = 0, elng = 0, elat = 0, 
                        key = "", session = None, **kwgs):
    """
    """
    params = {
        "key": key,
        "origin": f'{round(slng,6)},{round(slat,6)}',
        "destination": f'{round(elng,6)},{round(elat,6)}',
        "output": "json"
    }

    if mode == "walking":
        url = "https://restapi.amap.com/v3/direction/walking?" + urllib.parse.urlencode(params)
    
    if mode == "driving":
        params['strategy'] = kwgs.get("strategy", "10")
        params['extensions'] = kwgs.get("extensions", "all")
        url = "https://restapi.amap.com/v3/direction/driving?" + urllib.parse.urlencode(params)
    
    if mode == "transit":
        params['city'] = kwgs.get("city", "beijing")
        params['extensions'] = kwgs.get("extensions", "all")
        params['nightflag'] = kwgs.get("nightflag", "1")
        params['strategy'] = kwgs.get("strategy", "0" )
        url = "https://restapi.amap.com/v3/direction/transit/integrated?" + urllib.parse.urlencode(params)
    
    if mode == "riding":
        url = "https://restapi.amap.com/v4/direction/bicycling?" + urllib.parse.urlencode(params)

    print(url)
    if session is None:
        with requests.get(url, verify = certifi.where(), timeout=10) as req:
            return req.text 
    else:
        req = session.get(url, verify = certifi.where(), timeout=10)
        return req.text
    

def download_single_trip(rowidx, mode, slng, slat, elng, elat, session = None):
    """
    """
    import time
    import json

    json_doc = {}
    json_doc['rowidx'] = rowidx
    json_doc['slng'] = slng
    json_doc['slat'] = slat
    json_doc['elng'] = elng
    json_doc['elat'] = elat
    json_doc['downloadtime'] = time.time()
    json_doc['success'] = 0
    

    errortimes = 0
    while True:
        try:
            conn = GDKeyPool.get_database()
            gdkey, type_, avaitime = GDKeyPool.get_key(conn, type_ = mode)
            avaitime -= 1
            GDKeyPool.insert_key(conn, gdkey, type_, avaitime)
            conn.close()

            if (gdkey is None) and (avaitime is None):
                print("No avaiable Gaode Keys")  
                json_doc['rowidx'] = rowidx
                json_doc['slng'] = slng
                json_doc['slat'] = slat
                json_doc['elng'] = elng
                json_doc['elat'] = elat
                json_doc['downloadtime'] = time.time()
                json_doc['success'] = 0  
                print("No avaiable Geode Keys!")
                return json.dumps(json_doc)
            
            text = GDRoute(mode, slng, slat, elng, elat, key=gdkey, session=session)
            json_doc = json.loads(text)
        except Exception as e:
            print(e)
            errortimes += 1
            if errortimes > 5:
                json_doc['rowidx'] = rowidx
                json_doc['slng'] = slng
                json_doc['slat'] = slat
                json_doc['elng'] = elng
                json_doc['elat'] = elat
                json_doc['downloadtime'] = time.time()
                json_doc['success'] = 2
                return json.dumps(json_doc)

        if mode == "riding":
            if (int(json_doc['errcode']) == 0):
                json_doc['success'] = 1
                break

        if mode in ['transit', 'driving', 'walking']:
            # print(json_doc)
            # print(slng, slat, elng, elat)
            # print(url)
            if "status" not in json_doc.keys():
                print("status not exist!")
                json_doc['rowidx'] = rowidx
                json_doc['slng'] = slng
                json_doc['slat'] = slat
                json_doc['elng'] = elng
                json_doc['elat'] = elat
                json_doc['downloadtime'] = time.time()
                json_doc['success'] = 0
                return json.dumps(json_doc)
                            
            if int(json_doc['status']) == 1:
                json_doc['success'] = 1
                break
            
        if json_doc['infocode'] in ["10001", "10002", "10003", "10004", "10009", 
                                    "10013", "10015", "10020", "10029", "10044"]:
            conn = GDKeyPool.get_database()
            GDKeyPool.update_key(conn, gdkey, type_, 0)
            conn.close()
        

    json_doc['rowidx'] = rowidx
    json_doc['slng'] = slng
    json_doc['slat'] = slat
    json_doc['elng'] = elng
    json_doc['elat'] = elat
    json_doc['downloadtime'] = time.time()
    json_doc['success'] = 1
    
    return json.dumps(json_doc)

def batch_download(df:pd.DataFrame, mode, node_num=4):
    """
    """
    from concurrent.futures import ThreadPoolExecutor
    # from itertools import repeat

    assert "slng" in df.columns
    assert "slat" in df.columns
    assert "elng" in df.columns
    assert "elat" in df.columns
    assert "rowidx" in df.columns

    import requests
    list_sessions = [requests.Session() for i in range(node_num)]
    list_sessions = list_sessions * ( df.shape[0] // node_num + 1 )
    with ThreadPoolExecutor(max_workers=node_num) as executor:
        list_lines = executor.map(download_single_trip,
                                df['rowidx'].values,
                                repeat(mode),
                                list(df['slng'].values), 
                                list(df['slat'].values), 
                                list(df['elng'].values), 
                                list(df['elat'].values), 
                                list_sessions)
    return list(list_lines)

