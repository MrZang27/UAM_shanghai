import sqlite3
from datetime import datetime
import os
import yaml

def get_database(configfile = "config.yaml"):
    """
    """
    dbname = datetime.now().strftime("%Y%m%d")
    dbname = f"sqlite_{dbname}.db"
    if os.path.exists(dbname):
        conn = sqlite3.connect(dbname)
        return conn

    conn = sqlite3.connect(dbname)
    conn.execute("""CREATE TABLE GDKey
                (key TEXT    NOT NULL,
                type TEXT    NOT NULL,
                    avaitime INT NOT NULL);""")
    params = yaml.safe_load(open(configfile, 'r'))
    GDKeys = params['GDKeys']

    for key in GDKeys:
        conn.execute(f"""INSERT INTO GDKey (key, type, avaitime) VALUES ('{key}', 'driving', 4850)""")    
        conn.execute(f"""INSERT INTO GDKey (key, type, avaitime) VALUES ('{key}', 'walking', 4850)""")    
        conn.execute(f"""INSERT INTO GDKey (key, type, avaitime) VALUES ('{key}', 'transit', 4850)""")    
        conn.execute(f"""INSERT INTO GDKey (key, type, avaitime) VALUES ('{key}', 'cycling', 4850)""")
    conn.commit()
    return conn

def print_all(conn):
    """
    """
    cursor = conn.execute("SELECT key, type, avaitime FROM GDKey")
    for key, type, avaitime in cursor.fetchall():
        print(key, type, avaitime)
    cursor.close()


def get_key(conn, type_):
    """
    type_: "direction_driving"
    """
    cursor = conn.execute(f"SELECT key, type, avaitime FROM GDKey WHERE avaitime > 0 AND type = '{type_}' LIMIT 1")
    values = cursor.fetchone()
    cursor.close()
    if values is not None:
        key, type_, avaitime = values
        conn.execute(f"DELETE FROM GDKey WHERE key = '{key}' AND type = '{type_}' ") 
        conn.commit()
        return key, type_, avaitime
    else:
        return None, None, None

def insert_key(conn, key, type_, avaitime):
    """
    """
    conn.execute(f"""INSERT INTO GDKey (key, type, avaitime) VALUES ('{key}', '{type_}', {avaitime})""")
    # conn.execute(f"UPDATE GDKey set avaitime = {avaitime} where key = {key}")
    conn.commit()

def update_key(conn, key, type_, avaitime):
    """
    """
    # conn.execute(f"""INSERT INTO GDKey (key, avaitime) VALUES ('{key}', {avaitime})""")
    conn.execute(f"UPDATE GDKey set avaitime = {avaitime} where key = '{key}' AND type = '{type_}' ")
    conn.commit()
